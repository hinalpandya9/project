import java.io.*;
public class CSVReader
{
  
   public static void main(String[] args) throws FileNotFoundException {
     try{
     String dir1 = "/home/hinal/Downloads";
     String fileName1 = "crime.csv";
     String fileName2 = "tech.csv";
     String fileName3 = "sales.csv";
     String fileName4 = "estate.csv";
     String fileName5 = "sample.csv";
     FileReader r1 = new FileReader(dir1 + "/" + fileName1);
     System.out.println("CSV File Found");
     FileReader r2 = new FileReader(dir1 + "/" + fileName2);
     System.out.println("CSV File Found");
     FileReader r3 = new FileReader(dir1 + "/" + fileName3);
     System.out.println("CSV File Found");
     FileReader r4 = new FileReader(dir1 + "/" + fileName4);
     System.out.println("CSV File Found");
     FileReader r5 = new FileReader(dir1 + "/" + fileName5);
     System.out.println("CSV File Found");
    }catch(FileNotFoundException f){
        System.out.println("File not found");
    }
   } 
}
 